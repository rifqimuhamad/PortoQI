
<?php $__env->startSection('konten'); ?>
  <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 p-4 gap-4 text-black dark:text-white">
    <div class="md:col-span-2 xl:col-span-3">
      <h3 class="text-lg font-semibold">Edit Portfolio Item</h3>
    </div>
  </div>
  <div class=" py-4 px-6 lg:px-12 rounded-lg shadow-md">
    <form action="<?php echo e(route('portfolio.update', $data->id)); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <!-- Judul postingan -->
      <div class="mb-4">
        <label for="judul" class="text-white block mb-2 font-semibold">
          Judul
        </label>
        <input
          type="text"
          name="judul"
          id="judul"
          value="<?php echo e($data->judul); ?>"
          class="w-full bg-gray-800 rounded-lg py-2 px-3 text-white focus:outline-none focus:shadow-outline"
          required
        >

        <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Deskripsi postingan -->
    
      <div class="mb-4">
        <label for="isi" class="text-white block mb-2 font-semibold">
          Deskripsi
        </label>
        <input
          type="hidden"
          name="isi"
          id="isi"
          value="<?php echo e($data->isi); ?>"
          class="w-full bg-gray-800 rounded-lg py-2 px-3 text-white focus:outline-none focus:shadow-outline"
          required
        >
        <div class="w-full bg-gray-800 rounded-lg py-2 px-3  text-white focus:outline-none focus:shadow-outline" id="editor">
          <?php echo $data->isi; ?>
        </div>
                <?php $__errorArgs = ['isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Gambar postingan -->
      <div class="mb-4">
        <label for="image" class="text-white block mb-2 font-semibold">
          Gambar
        </label>
        <img src="<?php echo e(asset('img/portfolio/' . $data->image)); ?>" alt="<?php echo e($data->judul); ?>" class="h-10 w-10 object-cover sm:max-w-sm mx-auto" style="float: left;">
        <input
          type="file"
          name="image"
          id="image"
          class="w-full bg-gray-800 rounded-lg py-2 px-3 text-white focus:outline-none focus:shadow-outline"
        >

        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Kategori postingan -->
      <div class="mb-4">
        <label for="kategory" class="text-white block mb-2 font-semibold">
          Kategori
        </label>
        <select
          name="kategory"
          id="kategory"
          class="w-full bg-gray-800 rounded-lg py-2 px-3 text-white focus:outline-none focus:shadow-outline"
        >
          <option value="">Pilih Kategori</option>
          <option value="design" <?php echo e($data->kategory === 'design' ? 'selected' : ''); ?>>Design</option>
          <option value="webdesign" <?php echo e($data->kategory === 'webdesign' ? 'selected' : ''); ?>>Web Design</option>
          <option value="wordpress" <?php echo e($data->kategory === 'wordpress' ? 'selected' : ''); ?>>Wordpress</option>
          <option value="logo" <?php echo e($data->kategory === 'logo' ? 'selected' : ''); ?>>Logo</option>
          <option value="poster" <?php echo e($data->kategory === 'poster' ? 'selected' : ''); ?>>Poster</option>
          <option value="certificate" <?php echo e($data->kategory === 'certificate' ? 'selected' : ''); ?>>Certificate</option>
        </select>

        <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Tombol submit -->
      <div class="flex justify-center">
        <button
          type="submit"
          class="bg-blue-500 text-white py-2 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:shadow-outline"
        >
          Update
        </button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Xbrox\Downloads\Compressed\PortoQI\resources\views/dashboard/portfolio/edit.blade.php ENDPATH**/ ?>